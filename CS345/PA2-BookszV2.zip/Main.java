import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.border.Border;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;

public class Main {
  
  private JFrame frame;
  private JTree tree;
  private JLabel book;
  private JLabel cover;
  public Main() throws IOException {
    ArrayList<Book> bookList = BookListReader.readBookList(Main.class.getResourceAsStream("books.json"));
    
    for (int i = 0; i < bookList.size() - 1; i++) {
      for (int j = 0; j < bookList.size() - i - 1; j++) {
          if (bookList.get(j).getAuthor().compareTo(bookList.get(j + 1).getAuthor()) > 0) {
              Book temp = bookList.get(j);
              bookList.set(j, bookList.get(j + 1));
              bookList.set(j + 1, temp);
          }
      }
    }
    
    DefaultMutableTreeNode root = new DefaultMutableTreeNode("Authors");
    
    String author = "";
    DefaultMutableTreeNode authorNode = null;
    for (Book book: bookList) {
      if (book.getAuthor().equals(author)) {
        DefaultMutableTreeNode bookNode = new DefaultMutableTreeNode(book);
        authorNode.add(bookNode);
      } else {
        DefaultMutableTreeNode bookNode = new DefaultMutableTreeNode(book);
        authorNode = new DefaultMutableTreeNode(book.getAuthor());
        authorNode.add(bookNode);
        root.add(authorNode);
        
      }
      author = book.getAuthor();
    }
    
    frame = new JFrame("Bookz");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    Container contentPane = frame.getContentPane();
    contentPane.setLayout(new BorderLayout());
    tree = new JTree(root);
    tree.setRootVisible(false);
    tree.setShowsRootHandles(true);
    tree.getSelectionModel().addTreeSelectionListener(new TreeSelectionListener() {
      public void valueChanged(TreeSelectionEvent e) {
        DefaultMutableTreeNode selectedNode = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
        if (selectedNode != null && selectedNode.getUserObject() instanceof Book) {
          Book bookPic = (Book) selectedNode.getUserObject();
          book.setText(selectedNode.getUserObject().toString());
          cover.setIcon(new ImageIcon(Main.class.getResource(bookPic.getImageLink())));
        }
      }
    });
    contentPane.add(new JScrollPane(tree), BorderLayout.WEST);
    
    
    JPanel bookPanel = new JPanel();
    bookPanel.setLayout(new BoxLayout(bookPanel, BoxLayout.PAGE_AXIS));
    
    ImageIcon image = new ImageIcon(Main.class.getResource(""));
    cover = new JLabel(image);
    Border imageBorder = BorderFactory.createEmptyBorder(10, 10, 10, 10);
    cover.setBorder(imageBorder);
    bookPanel.add(cover);
    
    book = new JLabel("");
    Border border = BorderFactory.createEmptyBorder(10, 10, 10, 10);
    book.setBorder(border);
    bookPanel.add(book, BorderLayout.SOUTH);
    bookPanel.setPreferredSize(new Dimension(700,600));
    
    contentPane.add(bookPanel);
    
  }
  
  private void display() {
    frame.pack();
    frame.setVisible(true);
  }
  
  public static void main(String[] args) throws IOException {
    new Main().display();
  }
}
